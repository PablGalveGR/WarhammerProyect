<?php
include ('cabecera.php');
include("con_update.php");

$SQL2="SELECT *
	  FROM TIPO";
$RS2=mysqli_query($con,$SQL2);
$SQL3="SELECT *
	  FROM CLASE";
$RS3=mysqli_query($con,$SQL3);
$SQL4="SELECT *
	  FROM RAZA";
$RS4=mysqli_query($con,$SQL4);
if(isset($_GET['cod'])){
	$SQL = "SELECT * 
			FROM VEHICULOS 
			WHERE cod=".$_GET['cod'];
	$RS=mysqli_query($con,$SQL);
	while($fila=mysqli_fetch_assoc($RS)){
		$cod=$fila['cod'];
		$Nombre=$fila['Nombre'];
		$HP=$fila['HP'];
		$BF=$fila['BF'];
        $BL=$fila['BL'];
        $BP=$fila['BP'];
        $PA=$fila['PA'];
        $Puntos=$fila['Puntos'];
        $Raza=$fila['Raza'];
        $Tipo=$fila['Tipo'];
		$Clase=$fila['Clase'];
		$Imagen=$fila['Imagen'];
	}
?>
<!-- ***** Hero Area Start ***** -->
<div class="hero-area d-flex align-items-center">
        <!-- Hero Thumbnail -->
        <div class="hero-thumbnail equalize bg-img" style="background-image: url(<?php echo $Imagen?>);"></div>
        
        <!-- Hero Content -->
        <div class="hero-content equalize">
            <div class="container-fluid h-100">
                <div class="justify-content-center h-100">
                    <div class="h-100">
                    <form action="#" method="post">
                    <input type="hidden" size=3 name="cod" value="<?php echo $cod;?>">
                        <h2><input type="text" size=10 name="Nombre_F" value="<?php echo $Nombre;?>"></h2>
    <table bgcolor="white" width=100%>
    <tr>
        <td>
        Tipo de unidad
        </td>
        <td>
        <SELECT name='Tipo_F'>
		<?php
		while($fila=mysqli_fetch_assoc($RS2)){
			$cod_tipo=$fila['cod'];
			$nom_tipo=$fila['Nombre'];
			echo "<OPTION value='$cod_tipo'> $nom_tipo";}
			?>
		</SELECT>
        </td>
        <td class="dat">
        Clase de unidad
        </td>
        <td>
        <SELECT name='Clase_F'>
		<?php
		while($fila=mysqli_fetch_assoc($RS3)){
			$cod_Clase=$fila['cod'];
			$nom_Clase=$fila['Nombre'];
			echo "<OPTION value='$cod_Clase'> $nom_Clase";}
			?>
		</SELECT>
        </td>
        <td>
        Raza
        </td>
        <td>
		<SELECT name='Raza_F'>
		<?php
		while($fila=mysqli_fetch_assoc($RS4)){
			$cod_raza=$fila['cod'];
			$nom_raza=$fila['Nombre'];
			echo "<OPTION value='$cod_raza'> $nom_raza";}
			?>
		</SELECT>
        </td> 
        <td>
        Puntos
        </td>
        <td>
        <input type="text" size=2 name="Puntos_F" value="<?php echo $Puntos;?>">
        </td>
    </tr>
    <tr>
        <td>
        <center>HP</center>
        </td>
        <td>
        <center>BF</center>
        </td>
        <td>
        <center>BL</center>
        </td>
        <td>
        <center>BP</center>
        </td>
        <td>
        <center>PA</center>
        </td>
</tr>
<tr>
        <td>
        <center>
        <input type="text" size=1 name="HP_F" value="<?php echo $HP;?>">
            </center>
        </td>
        
        <td>
        <center>
        <input type="text" size=1 name="BF_F" value="<?php echo $BF;?>">
        </center>
        </td>
        
        <td>
        <center>
        <input type="text" size=1 name="BL_F" value="<?php echo $BL;?>">
            </center>
        </td>
        
        <td>
        <center>
        <input type="text" size=1 name="BP_F" value="<?php echo $BP;?>"
            </center>
        </td>
        
        <td>
        <center>
        <input type="text" size=1 name="PA_F" value="<?php echo $PA;?>">
            </center>
        </td>      
    </tr>
    <tr>
        <td colspan=8>
        <center>Reglas especiales</center>
        </td>
    </tr>
    <tr>
        <td>
        <?php 
        $SQL5="SELECT REG.Nombre, REG.Descripcion FROM REG_ESP REG , VEHI_REG UNIT WHERE REG.cod= UNIT.cod_reg AND UNIT.cod_vehi=$cod"; 
        $RS5=mysqli_query($con,$SQL5);
        while($row=mysqli_fetch_assoc($RS5)){
            $nom_reg=$row["Nombre"];
            $des_reg=$row['Descripcion'];
            print "<b>$nom_reg</b><br>";
            print"$des_reg<br>";
        }
        ?>
        </td>
    </tr>
    <tr><td align=center colspan=10><input type="submit" name="modificar" value="Modificar"></td></tr>
	</form>
    </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Portfolio Menu -->
        <div class="sonar-portfolio-menu">
            <div class="text-center portfolio-menu">
            </div>
        </div>
    </div>
<?php
}elseif(isset($_POST['modificar'])){
    $cod_F=$_POST['cod_F'];
    $Nombre_F=$_POST['Nombre_F'];
    $HP_F=$_POST['HP_F'];
    $BF_F=$_POST['BF_F'];
    $BL_F=$_POST['BL_F'];
    $BP_F=$_POST['BP_F'];
    $PA_F=$_POST['PA_F'];
    $Raza_F=$_POST['Raza_F'];
    $Tipo_F=$_POST['Tipo_F'];
    $Clase_F=$_POST['Clase_F'];
    $Puntos_F=$_POST['Puntos_F'];
    $Imagen_F=$_POST['Imagen_F'];
    $SQL="UPDATE  VEHICULOS 
          SET Nombre='$Nombre_F', HP='$HP_F', BF='$BF_F', BL='$BL_F', BP='$BP_F', PA='$PA_F', Raza='$Raza_F', Tipo='$Tipo_F', Clase='$Clase_F', Puntos='$Puntos_F', Imagen='$Imagen_F',
          WHERE cod='$cod'";
    echo "$SQL\n";
    if(mysqli_query($con,$SQL)){ 
        echo "Se modificaron los datos con exito";
    }
    else{
        echo "No se modificaron los datos con exito";
    }
}
mysqli_close($con);
include ("footer.php");
?>