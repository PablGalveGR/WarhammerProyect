<?php
include ('cabecera.php');
include("con_insert.php");
$SQL2="SELECT *
	  FROM TIPO";
$RS2=mysqli_query($con,$SQL2);
$SQL3="SELECT *
	  FROM CLASE";
$RS3=mysqli_query($con,$SQL3);
$SQL4="SELECT *
	  FROM RAZA";
$RS4=mysqli_query($con,$SQL4);
if(!isset($_POST["crear"]))
{
?>
    <!-- ***** Hero Area Start ***** -->
    <div class="hero-area d-flex align-items-center">
        <!-- Hero Thumbnail -->
        <div class="hero-thumbnail equalize bg-img" style="background-image: url(img/bg-img/portfolio.jpg);"></div>
        
        <!-- Hero Content -->
        <div class="hero-content equalize">
            <div class="container-fluid h-100">
                <div class="row h-100 align-items-center justify-content-center">
                <div class="h-100">
                <form action="#" method="post">
                        <h2><input type="text" size=10 name="Nombre_F"></h2>

<table bgcolor="white" width=100% border=1>
    <tr>
        <td style="padding-right: 15px;">
        Tipo de unidad
        </td>
        <td style="padding-right: 15px;">
        <SELECT name='Tipo_F'>
		<?php
		while($fila=mysqli_fetch_assoc($RS2)){
			$cod_tipo=$fila['cod'];
			$nom_tipo=$fila['Nombre'];
			echo "<OPTION value='$cod_tipo'> $nom_tipo";}
			?>
		</SELECT>
        </td>
        <td style="padding-right: 15px;">
        Clase de unidad
        </td>
        <td style="padding-right: 15px;">
        <SELECT name='Clase_F'>
		<?php
		while($fila=mysqli_fetch_assoc($RS3)){
			$cod_Clase=$fila['cod'];
			$nom_Clase=$fila['Nombre'];
			echo "<OPTION value='$cod_Clase'> $nom_Clase";}
			?>
		</SELECT>
        </td style="padding-right: 15px;">
        <td>
        Raza
        </td>
        <td style="padding-right: 15px;">
        <SELECT name='Raza_F'>
		<?php
		while($fila=mysqli_fetch_assoc($RS4)){
			$cod_raza=$fila['cod'];
			$nom_raza=$fila['Nombre'];
			echo "<OPTION value='$cod_raza'> $nom_raza";}
			?>
		</SELECT>
        </td>
        <td style="padding-right: 15px;">
        Puntos
        </td>
        <td style="padding-right: 15px;">
        <input type="text" size=2 name="Puntos_F">
        </td>
</tr>
<tr>

        <td>
        <center>HA</center>
        </td>
        <td>
        <center>HP</center>
        </td>
        <td>
        <center>F</center>
        </td>
        <td>
        <center>R</center>
        </td>
        <td>
        <center>H</center>
        </td>
        <td>
        <center>I</center>
        </td>
        <td>
        <center>A</center>
        </td>
        <td>
        <center>L</center>
        </td>
        <td style="padding-right: 15px;">
        <center>SV</center>
        </td>
        <td>
        <center>Cantidad de miniaturas</center>
        </td>
</tr>
<tr>
        <td><center>
        <input type="text" size=1 name="HA_F">
            </center>
        </td>
        
        <td><center>
        <input type="text" size=1 name="HP_F">
            </center>
        </td>
        
        <td><center>
        <input type="text" size=1 name="F_F">
        </center>
        </td>
        
        <td><center>
        <input type="text" size=1 name="R_F">
            </center>
        </td>
        
        <td><center>
        <input type="text" size=1 name="H_F">
            </center>
        </td>
        
        <td><center>
        <input type="text" size=1 name="I_F">
            </center>
        </td>
        
        <td><center>
        <input type="text" size=1 name="A_F">
            </center>
        </td>
        
        <td><center>
        <input type="text" size=1 name="L_F">
            </center>
        </td>
        
        <td><center>
        <input type="text" size=1 name="SV_F">
            </center>
        </td>                
        <td><center>
        <input type="text" size=1 name="Cantidad_F">
            </center>
        </td>
        
    </tr>
    <tr>
     <td>
        Imagen
     </td>
     <td <td colspan=9>
     <center>
        <input type="file" name="imagen" value="imagen">
    </center>
     </td>
    </tr>
    <tr>
        <td align=center colspan=10>
            <input type="submit" name="crear" value="Crear">
        </td>
    </tr>
    </form>
    </table>
                </div>
            </div>
        </div>
<?php
}
else{
    $cod=rand(0,999999999);
    $nom_unit=$_POST['Nombre_F'];
    $HA_unit=$_POST['HA_F'];
    $HP_unit=$_POST['HP_F'];
    $F_unit=$_POST['F_F'];
    $R_unit=$_POST['R_F'];
    $H_unit=$_POST['H_F'];
    $I_unit=$_POST['I_F'];
    $A_unit=$_POST['A_F'];
    $L_unit=$_POST['L_F'];
    $SV_unit=$_POST['SV_F'];
    $Puntos_unit=$_POST['Puntos_F'];
    $Raza=$_POST['Raza_F'];
    $Cantidad=$_POST['Cantidad_F'];
    $tip_unit=$_POST['Tipo_F'];
    $clas_unit=$_POST['Clase_F'];
    //Upload//
    if (is_uploaded_file ($_FILES['imagen']['tmp_name'])){
        $filename=$_FILES['imagen']['name'];
        $ext = substr($filename, strrpos($filename, '.') + 1);
        //echo $ext;
	    $nombreDirectorio = "img/wiki/";
	//$nombreFichero = $_FILES['imagen']['name'];
	    $nombreFichero=$nom_unit;
	    $nombreFichero_ext="$nombreFichero.$ext";
	    $nombreCompleto = $nombreDirectorio . $nombreFichero_ext;
	        if (is_file($nombreCompleto))
	        {
		    $idUnico = time();
		    $nombreFichero = $idUnico . "-" . $nombreFichero_ext;
	        }
	    move_uploaded_file ($_FILES['imagen']['tmp_name'],
	    $nombreDirectorio . $nombreFichero_ext);
	    //print ("Fichero $nombreFichero_ext subido.\n");


        }
        else{
        print ("No se ha podido subir el fichero\n");
        }
    $img=$nombreCompleto;
    $SQL_IN="INSERT INTO UNIDAD values
    ($cod, '$nom_unit', $HA_unit, $HP_unit, $F_unit, $R_unit, $H_unit, $I_unit, $A_unit, $L_unit, '$SV_unit', $Puntos_unit, '$img', $Raza, $Cantidad, $tip_unit, $clas_unit);";
    $RS_IN=mysqli_query($con,$SQL_IN);
    if($RS_IN){
        echo "Se ha añadido  $nom_unit";
    }
    else{
        echo "No se ha añadido $nom_unit";
        echo $SQL_IN;
    }
    mysqli_close($con);
}
include ("footer.php");
?>