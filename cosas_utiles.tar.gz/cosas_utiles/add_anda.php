<?php
include ('cabecera.php');
include("con_insert.php");
if(!isset($_POST["send"]))
{
?>
    <!-- ***** Hero Area Start ***** -->
    <div class="hero-area d-flex align-items-center">
        <!-- Hero Thumbnail -->
        <div class="hero-thumbnail equalize bg-img" style="background-image: url(img/bg-img/portfolio.jpg);"></div>
        
        <!-- Hero Content -->
        <div class="hero-content equalize">
            <div class="container-fluid h-100">
                <div class="row h-100 align-items-center justify-content-center">
                    <div class="col-12 col-md-8">
                        <div class="line"></div>
                        <h2>Creador de unidades</h2>
<table bgcolor=white border='1' align=center>
<form action="#" method="POST" ENCTYPE="multipart/form-data">
<tr>
    <td>
        Nombre de la unidad
    </td>
    <td>
        <input type=text name=nombre>
    </td>
</tr>
<tr>
    <td>
        Habilidad de Armas (CaC)
    </td>
    <td>
        <input type=text name=HA>
    </td>
</tr>
<tr>
    <td>
        Habilidad de Proyectiles
    </td>
    <td>
        <input type=text name=HP>
    </td>
</tr>
<tr>
    <td>
        Fuerza
    </td>
    <td>
        <input type=text name=F>
    </td>
</tr>
<tr>
    <td>
        Resistencia
    </td>
    <td>
        <input type=text name=R>
    </td>
</tr>
<tr>
    <td>
        Heridas
    </td>
    <td>
        <input type=text name=H>
    </td>
</tr>
<tr>
    <td>
        Iniciativa
    </td>
    <td>
        <input type=text name=I>
    </td>
</tr>
<tr>
    <td>
        Ataques
    </td>
    <td>
        <input type=text name=A>
    </td>
</tr>
<tr>
    <td>
        Liderazgo
    </td>
    <td>
        <input type=text name=L>
    </td>
</tr>
<tr>
    <td>
        Salvación por armadura
    </td>
    <td>
        <input type=text name=SV>
    </td>
</tr>
<tr>
    <td>
        Puntos
    </td>
    <td>
        <input type=text name=Puntos>
    </td>
</tr>
<tr>
    <td>
        Imagen
    </td>
    <td>
        <input type="file" name="imagen">
    </td>
</tr>
<tr>
    <td>
        Raza
    </td>
    <td>
        <select name=Raza>
        <?php
            $SQL="SELECT * FROM RAZA";
            $RS=mysqli_query($con,$SQL);
            while($row=mysqli_fetch_assoc($RS)){
                $cod_raza=$row["cod"];
                $nom_raza=$row["Nombre"];
            
                print "<option value='$cod_raza'>$nom_raza</option>";
        };
        ?>
        </select>
    </td>
</tr>
<tr>
    <td>
        Cantidad
    </td>
    <td>
        <input type=text name=Cantidad>
    </td>
</tr>
<tr>
    <td>
        Tipo de unidad
    </td>
    <td>
        <select name=Tipo>
        <?php
            $SQL="SELECT * FROM TIPO";
            $RS=mysqli_query($con,$SQL);
            while($row=mysqli_fetch_assoc($RS)){
                $cod_tip=$row["cod"];
                $nom_tip=$row["Nombre"];
            
                print "<option value='$cod_tip'>$nom_tip</option>";
        };
        ?>
        </select>
    </td>
</tr>
<tr>
    <td>
        Clase de unidad
    </td>
    <td>
        <select name=Clase>
        <?php
            $SQL="SELECT * FROM CLASE";
            $RS=mysqli_query($con,$SQL);
            while($row=mysqli_fetch_assoc($RS)){
                $cod_clas=$row["cod"];
                $nom_clas=$row["Nombre"];
            
                print "<option value='$cod_clas'>$nom_clas</option>";
        };
        ?>
        </select>
    </td>
</tr>
<tr>
    <td>
    </td>
    <td>
        <input type=submit name=send value=Añadir>
    </td>
</tr>
</form>
</table>
</div>
                </div>
            </div>
        </div>
<?php
}
else{
    $cod=rand(0,999999999);
    $nom_unit=$_POST['nombre'];
    $HA_unit=$_POST['HA'];
    $HP_unit=$_POST['HP'];
    $F_unit=$_POST['F'];
    $R_unit=$_POST['R'];
    $H_unit=$_POST['H'];
    $I_unit=$_POST['I'];
    $A_unit=$_POST['A'];
    $L_unit=$_POST['L'];
    $SV_unit=$_POST['SV'];
    $Puntos_unit=$_POST['Puntos'];
    $Raza=$_POST['Raza'];
    $Cantidad=$_POST['Cantidad'];
    $tip_unit=$_POST['Tipo'];
    $clas_unit=$_POST['Clase'];
    //Upload//
    if (is_uploaded_file ($_FILES['imagen']['tmp_name'])){
        $filename=$_FILES['imagen']['name'];
        $ext = substr($filename, strrpos($filename, '.') + 1);
        //echo $ext;
	    $nombreDirectorio = "img/wiki/";
	//$nombreFichero = $_FILES['imagen']['name'];
	    $nombreFichero=$nom_unit;
	    $nombreFichero_ext="$nombreFichero.$ext";
	    $nombreCompleto = $nombreDirectorio . $nombreFichero_ext;
	        if (is_file($nombreCompleto))
	        {
		    $idUnico = time();
		    $nombreFichero = $idUnico . "-" . $nombreFichero_ext;
	        }
	    move_uploaded_file ($_FILES['imagen']['tmp_name'],
	    $nombreDirectorio . $nombreFichero_ext);
	    //print ("Fichero $nombreFichero_ext subido.\n");

        }
        else{
        print ("No se ha podido subir el fichero\n");
        }
    $img=$nombreCompleto;
    $SQL_IN="INSERT INTO UNIDAD values
    ($cod, '$nom_unit', $HA_unit, $HP_unit, $F_unit, $R_unit, $H_unit, $I_unit, $A_unit, $L_unit, '$SV_unit', $Puntos_unit, '$img', $Raza, $Cantidad, $tip_unit, $clas_unit);";
    $RS_IN=mysqli_query($con,$SQL_IN);
    if($RS_IN){
        echo "Se ha añadido  $nom_unit";
    }
    else{
        echo "No se ha añadido $nom_unit";
        echo $SQL_IN;
    }
    mysqli_close($con);
}
include ("footer.php");
?>