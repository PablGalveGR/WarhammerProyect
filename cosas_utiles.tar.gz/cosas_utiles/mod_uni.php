<?php
include ('cabecera.php');
include("con_update.php");

$SQL2="SELECT *
	  FROM TIPO";
$RS2=mysqli_query($con,$SQL2);
$SQL3="SELECT *
	  FROM CLASE";
$RS3=mysqli_query($con,$SQL3);
$SQL4="SELECT *
	  FROM RAZA";
$RS4=mysqli_query($con,$SQL4);
if(isset($_GET['cod'])){
	$SQL = "SELECT * 
			FROM UNIDAD 
			WHERE cod=".$_GET['cod'];
	$RS=mysqli_query($con,$SQL);
	while($fila=mysqli_fetch_assoc($RS)){
		$cod=$fila['cod'];
		$Nombre=$fila['Nombre'];
		$HA=$fila['HA'];
		$HP=$fila['HP'];
		$F=$fila['F'];
		$R=$fila['R'];
        $H=$fila['H'];
        $I=$fila['I'];
        $A=$fila['A'];
        $L=$fila['L'];
        $SV=$fila['SV'];
        $Puntos=$fila['Puntos'];
        $Imagen=$fila['Imagen'];
        $Raza=$fila['Raza'];
        $Cantidad=$fila['Cantidad'];
        $Tipo=$fila['Tipo'];
        $Clase=$fila['Clase'];
	}

?>
?>
<!-- ***** Hero Area Start ***** -->
<div class="hero-area d-flex align-items-center">
        <!-- Hero Thumbnail -->
        <div class="hero-thumbnail equalize bg-img" style="background-image: url(<?php echo $Imagen?>);"></div>
        
        <!-- Hero Content -->
        <div class="hero-content equalize">
            <div class="container-fluid h-100">
                <div class="row h-100 align-items-center justify-content-center">
                    <div class="h-100">
                    <form action="#" method="post">
                    <h2><input type="text" size=10 name="Nombre_F" value="<?php echo $Nombre;?>"></h2>
    <table bgcolor="white" width=100% border=1>
    <input type="hidden" name="cod_F" value="<?php echo $cod;?>">

    <tr>
        <td style="padding-right: 15px;">
        Tipo de unidad
        </td>
        <td style="padding-right: 15px;">
        <SELECT name='Tipo_F'>
		<?php
		while($fila=mysqli_fetch_assoc($RS2)){
			$cod_tipo=$fila['cod'];
			$nom_tipo=$fila['Nombre'];
			echo "<OPTION value='$cod_tipo'> $nom_tipo";}
			?>
		</SELECT>
        </td>
        <td style="padding-right: 15px;">
        Clase de unidad
        </td>
        <td style="padding-right: 15px;">
        <SELECT name='Clase_F'>
		<?php
		while($fila=mysqli_fetch_assoc($RS3)){
			$cod_Clase=$fila['cod'];
			$nom_Clase=$fila['Nombre'];
			echo "<OPTION value='$cod_Clase'> $nom_Clase";}
			?>
		</SELECT>
        </td style="padding-right: 15px;">
        <td>
        Raza
        </td>
        <td style="padding-right: 15px;">
        <SELECT name='Raza_F'>
		<?php
		while($fila=mysqli_fetch_assoc($RS4)){
			$cod_raza=$fila['cod'];
			$nom_raza=$fila['Nombre'];
			echo "<OPTION value='$cod_raza'> $nom_raza";}
			?>
		</SELECT>
        </td>
        <td style="padding-right: 15px;">
        Puntos
        </td>
        <td style="padding-right: 15px;">
        <input type="text" size=2 name="Puntos_F" value="<?php echo $Puntos;?>">
        </td>
</tr>
<tr>

        <td>
        <center>HA</center>
        </td>
        <td>
        <center>HP</center>
        </td>
        <td>
        <center>F</center>
        </td>
        <td>
        <center>R</center>
        </td>
        <td>
        <center>H</center>
        </td>
        <td>
        <center>I</center>
        </td>
        <td>
        <center>A</center>
        </td>
        <td>
        <center>L</center>
        </td>
        <td style="padding-right: 15px;">
        <center>SV</center>
        </td>
        <td>
        <center>Cantidad de miniaturas</center>
        </td>
</tr>
<tr>
        <td><center>
        <input type="text" size=1 name="HA_F" value="<?php echo $HA;?>">
            </center>
        </td>
        
        <td><center>
        <input type="text" size=1 name="HP_F" value="<?php echo $HP;?>">
            </center>
        </td>
        
        <td><center>
        <input type="text" size=1 name="F_F" value="<?php echo $F;?>">
        </center>
        </td>
        
        <td><center>
        <input type="text" size=1 name="R_F" value="<?php echo $R;?>">
            </center>
        </td>
        
        <td><center>
        <input type="text" size=1 name="H_F" value="<?php echo $H;?>">
            </center>
        </td>
        
        <td><center>
        <input type="text" size=1 name="I_F" value="<?php echo $I;?>">
            </center>
        </td>
        
        <td><center>
        <input type="text" size=1 name="A_F" value="<?php echo $A;?>">
            </center>
        </td>
        
        <td><center>
        <input type="text" size=1 name="L_F" value="<?php echo $L;?>">
            </center>
        </td>
        
        <td><center>
        <input type="text" size=1 name="SV_F" value="<?php echo $SV;?>">
            </center>
        </td>                
        <td><center>
        <input type="text" size=1 name="Cantidad_F" value="<?php echo $Cantidad;?>">
            </center>
        </td>
        
    </tr>
    </center>
    <tr>
        <td colspan=10>
        <center>Reglas especiales</center>
        </td>
    </tr>
    <tr>
        <td colspan=10>
        <?php 
        $SQL5="SELECT REG.Nombre, REG.Descripcion FROM REG_ESP REG , UNIT_REG UNIT WHERE REG.cod= UNIT.cod_reg AND UNIT.cod_unit=$cod"; 
        $RS5=mysqli_query($con,$SQL5);
        while($row=mysqli_fetch_assoc($RS5)){
            $nom_reg=$row["Nombre"];
            $des_reg=$row['Descripcion'];
            print "<b>$nom_reg</b><br>";
            print"$des_reg<br>";
        }
        ?>
        </td>
    </tr>
    <tr><td align=center colspan=10><input type="submit" name="modificar" value="modificar"></td></tr>
    </form>
    </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Portfolio Menu -->
        <div class="sonar-portfolio-menu">
            <div class="text-center portfolio-menu">
            </div>
        </div>
    </div>
    
<?php
}elseif(isset($_POST['modificar'])){
    $cod_F=$_POST['cod_F'];
    $Nombre_F=$_POST['Nombre_F'];
    $HA_F=$_POST['HA_F'];
    $HP_F=$_POST['HP_F'];
    $F_F=$_POST['F_F'];
    $R_F=$_POST['R_F'];
    $H_F=$_POST['H_F'];
    $I_F=$_POST['I_F'];
    $A_F=$_POST['A_F'];
    $L_F=$_POST['L_F'];
    $SV_F=$_POST['SV_F'];
    $Puntos_F=$_POST['Puntos_F'];
    $Imagen_F=$_POST['Imagen_F'];
    $Raza_F=$_POST['Raza_F'];
    $Cantidad_F=$_POST['Cantidad_F'];
    $Tipo_F=$_POST['Tipo_F'];
    $Clase_F=$_POST['Clase_F'];
    $SQL="UPDATE  UNIDAD 
          SET Nombre='$Nombre_F', HA='$HA_F', HP='$HP_F', F='$F_F', R='$R_F', H='$H_F', I='$I_F', A='$A_F', L='$L_F', SV='$SV_F', Puntos='$Puntos_F', Imagen='$Imagen_F', Raza='$Raza_F', Cantidad='$Cantidad_F', Tipo='$Tipo_F', Clase='$Clase_F',
          WHERE cod='$cod_F'";
    echo "$SQL\n";
    if(mysqli_query($con,$SQL)){ 
        echo "Se modificaron los datos con exito";
    }
}
mysqli_close($con);
include ("footer.php");
?>